#!/bin/bash

supervisorctl stop hanabi-live
