const phaserGlobals = {
    hands: null,
    playArea: null,
};
module.exports = phaserGlobals;
